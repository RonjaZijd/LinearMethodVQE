#!/usr/bin/env bash
#XXX default clang compiler does not support openmp, shall we use gcc?
cd ./pyscf/lib
curl -L https://github.com/fishjojo/pyscf-deps/raw/master/pyscf-1.7.5-deps-macos-10.14.tar.gz | tar xzf -
mkdir build; cd build
cmake -DBUILD_LIBXC=OFF -DBUILD_XCFUN=OFF ..
make -j4
cd ../../..
